# 🚀 دليل البدء السريع

## خطوات التثبيت والتشغيل

### الخطوة 1: تثبيت الحزم
\`\`\`bash
cd /workspaces/maximum
npm install
\`\`\`

### الخطوة 2: تشغيل الخادم التطويري
\`\`\`bash
npm run dev
\`\`\`

### الخطوة 3: فتح في المتصفح
انتقل إلى:
\`\`\`
http://localhost:3000
\`\`\`

## 🎯 الميزات الرئيسية

### 1. **لوحة إعلانية ثلاثية الأبعاد (3D Billboard)**
- رسوميات عالية الجودة باستخدام Three.js
- تتابع حركة الماوس الحي
- إضاءة واقعية متعددة المصادر
- خلفية من النجوم المتحركة
- تأثيرات توهج احترافية

### 2. **شريط التنقل العلوي (Header)**
- تصميم عصري مع تأثير Glass
- روابط تنقل سلسة
- حركات عند التحويم
- زر "البدء الآن" تفاعلي

### 3. **قسم الخدمات (Services)**
- عرض 4 خدمات رئيسية
- بطاقات بتأثيرات توهج
- حركات عند المرور
- تصميم متجاوب

### 4. **المحفظة (Portfolio)**
- معرض الأعمال بشبكة
- صور بتأثير الزووم
- معلومات على المرور
- تصنيفات العمل

### 5. **نموذج الاتصال (Contact)**
- نموذج جميل مع التحقق
- معلومات الاتصال
- وسائل التواصل
- التذييل

## 📁 البنية الأساسية

```
📦 /workspaces/maximum
├── 📂 app/                   # صفحات وتخطيطات Next.js
│   ├── page.tsx             # الصفحة الرئيسية
│   └── layout.tsx           # التخطيط الرئيسي
│
├── 📂 components/           # مكونات React
│   ├── Billboard3D.tsx      # اللوحة الإعلانية 3D
│   ├── Header.tsx           # الشريط العلوي
│   ├── Services.tsx         # قسم الخدمات
│   ├── Portfolio.tsx        # المحفظة
│   ├── Contact.tsx          # الاتصال والقدم
│   └── ParticleSystem.tsx   # نظام الجزيئات
│
├── 📂 styles/               # أنماط CSS
│   └── globals.css          # الأنماط العامة
│
├── 📄 package.json          # الحزم والتبعيات
├── 📄 next.config.js        # إعدادات Next.js
├── 📄 tsconfig.json         # إعدادات TypeScript
├── 📄 tailwind.config.js    # إعدادات Tailwind
└── 📄 postcss.config.js     # إعدادات PostCSS
```

## 🎨 التخصيص

### تغيير الألوان الأساسية

تحرير \`tailwind.config.js\`:

\`\`\`javascript
colors: {
  primary: '#667eea',      // اللون الأساسي (الأزرق البنفسجي)
  secondary: '#764ba2',    // اللون الثانوي
  dark: '#0a0e27',        // الخلفية الداكنة
  darker: '#050812',      // خلفية أغمق
}
\`\`\`

### تغيير النصوص والعناوين

تحرير الملفات في \`/components\` وتعديل القيم:

\`\`\`tsx
<Billboard3D 
  title="عنوانك المخصص"
  subtitle="نصك الفرعي"
  imageUrl="رابط صورتك"
/>
\`\`\`

## 🚀 الأوامر الأساسية

| الأمر | الوصف |
|-----|-------|
| \`npm run dev\` | تشغيل الخادم التطويري |
| \`npm run build\` | بناء للإنتاج |
| \`npm start\` | تشغيل الإنتاج |
| \`npm run lint\` | التحقق من الأخطاء |

## 📦 المكتبات المستخدمة

- **Next.js 14** - إطار عمل React
- **Three.js** - رسوميات ثلاثية الأبعاد
- **React Three Fiber** - ربط Three.js مع React
- **Tailwind CSS** - أنماط CSS
- **Framer Motion** - حركات وتأثيرات
- **GSAP** - مكتبة حركات متقدمة
- **TypeScript** - أمان النوع

## 🔧 المتطلبات

- **Node.js** 16 أو أحدث
- **npm** أو **yarn**
- **متصفح حديث** مع دعم WebGL

## 📚 موارد إضافية

- [Documentation Next.js](https://nextjs.org/docs)
- [Documentation Three.js](https://threejs.org/docs)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [Framer Motion](https://www.framer.com/motion/)

## 🆘 حل المشاكل

### المشكلة: "Port 3000 is already in use"
\`\`\`bash
# استخدم منفذ مختلف
npm run dev -- -p 3001
\`\`\`

### المشكلة: "Module not found"
\`\`\`bash
# أعد تثبيت الحزم
rm -rf node_modules package-lock.json
npm install
\`\`\`

### المشكلة: الرسوميات 3D لا تظهر
- تأكد أن متصفحك يدعم WebGL
- جرب متصفح آخر (Chrome, Firefox, Safari)
- تحقق من وحدة معالجة الرسوميات (GPU)

## ✅ المراجعة قبل النشر

- [ ] تثبيت جميع الحزم بنجاح
- [ ] تشغيل الموقع بدون أخطاء
- [ ] اختبار الروابط والنماذج
- [ ] التحقق من الأداء
- [ ] اختبار على أجهزة مختلفة

## 🎉 ممتاز!

الآن أنت جاهز لإطلاق موقعك الجديد!

استمتع بالتطوير! 🚀
