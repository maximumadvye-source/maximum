# أماكن الحفظ المهمة

## ملفات المشروع الرئيسية

```
/workspaces/maximum/
├── 📦 package.json              # الحزم والتبعيات
├── ⚙️ next.config.js             # إعدادات Next.js
├── 🎨 tailwind.config.js         # إعدادات Tailwind CSS
├── 📝 tsconfig.json              # إعدادات TypeScript
├── 🔧 postcss.config.js          # إعدادات PostCSS
├── 🚀 README.md                  # دليل المشروع
├── 📖 DEVELOPMENT.md             # دليل التطوير
├── .eslintrc.json               # إعدادات ESLint
├── .prettierrc                  # إعدادات Prettier
└── .gitignore                   # ملف تجاهل Git
```

## المكونات

```
/components/
├── ✨ Billboard3D.tsx           # اللوحة الإعلانية ثلاثية الأبعاد
├── 🎬 Header.tsx                # شريط التنقل العلوي
├── 🛠️ Services.tsx              # قسم الخدمات
├── 🎨 Portfolio.tsx             # قسم المحفظة
├── 📧 Contact.tsx               # نموذج الاتصال والقدم
└── ✨ ParticleSystem.tsx        # نظام الجزيئات
```

## الصفحات

```
/app/
├── 📄 page.tsx                  # الصفحة الرئيسية
└── 🎨 layout.tsx                # التخطيط الرئيسي
```

## الأنماط

```
/styles/
└── 🎨 globals.css              # الأنماط العامة والحركات
```
